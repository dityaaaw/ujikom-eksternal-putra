import React from "react";

const AboutUs = () => {
    return(
        <div>
            <h1>About Us</h1>
            <img src="https://1.bp.blogspot.com/-GctvqQVW0tU/W2uO8rTZXkI/AAAAAAAA_PU/82NEBXrHIqcrqULfFH3o321TvRq4XZJgwCK4BGAYYCw/s1600/picture-701764.jpg" alt="" />
            {/* <P>Welcome To Our Website</P> */}
            <p>Seputar Indonesia bermula dari berita Seputar Jakarta yang kala itu digagas sebagai program berita ringan serta bersifat nonpolitis, 
                yang ditayangkan RCTI pada saat masih mengudara melalui dekoder. Perbedaannya adalah cakupan liputan yang lebih luas ke seluruh wilayah Indonesia
Sebelum Seputar Indonesia hadir, Seputar Jakarta merupakan program berita RCTI. Sebelum Seputar Jakarta ditayangkan, 
RCTI terlebih dahulu merintis program berita dengan penayangan laporan obituari. Adapun tayangan tersebut berupa liputan obituari 
Tuti Indra Malaon, Sarwo Edhie Wibowo, serta Syarief Thayeb.
 Laporan Obituari tersebut mendapat perhatian pemirsa karena lebih menarik
  dan dianggap berita tersebut tidak mungkin ditayangkan di TVRI sebagai stasiun televisi satu-satunya dan kala itu lebih beriorientasi kepada pejabat dan pemerintah
  . Setelah tidak ada lagi berita obituari, RCTI mulai mempersiapkan berita nonpolitis dan quasi berita yaitu Seputar Jakarta. Quasi berita yang dimaksud
   adalah karena isi berita berupa hubungan sosial manusia, kriminal, kecelakaan, serta menghindari berita politik Dan Kini merambah ke Media Digital sejak 2017 hingga saat ini.</p>
        </div>
    )
}

export default AboutUs;