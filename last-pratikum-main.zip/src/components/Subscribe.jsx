import React, { useState } from 'react';

function Subscribe() {
  const [email, setEmail] = useState('');

  const handleChange = (e) => {
    setEmail(e.target.value);
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    console.log('Email yang disubmit:', email);
    alert('Terima kasih! Anda berhasil berlangganan.');
    setEmail('');
  };

  return (
    <div>
      <h2>Subscribe</h2>
      <form onSubmit={handleSubmit}>
        <input
          type="email"
          placeholder="Masukkan alamat email Anda"
          value={email}
          onChange={handleChange}
          required
        />
        <button type="submit">Subscribe</button>
      </form>
    </div>
  );
}

export default Subscribe;