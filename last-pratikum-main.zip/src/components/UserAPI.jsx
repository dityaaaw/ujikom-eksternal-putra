let users = [];

const baseURL = "http://localhost:4001"
const url = '${baseURL}/projects'

const createUser = (userData) => {
    users.push(userData);
};

const findUserByUsername = (username) => {
    return users.find(user => user.username === username);
};

const login = (username, password) => {
    const user = findUserByUsername(username);
    if (user && user.password === password) {
        return user;
    } else {
        return null;
    }
};

export const userAPI = {
    create: createUser,
    login: login,
    getAllUsers: () => users,
    getUserById: (id) => users.find(user => user.id === id),
    updateUser: (id, newData) => {
        const index = users.findIndex(user => user.id === id);
        if (index !== -1) {
            users[index] = { ...users[index], ...newData };
        }
    },
    deleteUser: (id) => {
        users = users.filter(user => user.id !== id);
    }
}