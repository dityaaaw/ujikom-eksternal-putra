import React, { useState } from 'react';
import {userAPI,} from "../components/UserAPI"
import { Link } from 'react-router-dom';
import '../components/login.css';

const Login = ({ onLogin, onChange }) => {
    const [username, setUsername] = useState('');
    const [password, setPassword] = useState('');

    const handleLogin = () => {
        const user = userAPI.login(username, password)
        if (user) {
            alert('Login successful!');
            onLogin(user);
        } else {
            alert('Username atau Password anda salah!');
        }
    };

    return (
        <div>
            <h2>Login</h2>
            <div className='login'>
            <div>
                <label>Username:</label>
                <input type="text" value={username} placeholder='Masukan Username Anda' onChange={(e) => setUsername(e.target.value)} />
            </div>
            <div>
                <label>Password:</label>
                <input type="password" value={password} placeholder='Masukan Password Anda' onChange={(e) => setPassword(e.target.value)} />
            </div>
            <button onClick={handleLogin}>Login</button>
            <Link id='btn' to = "http://localhost:3000/signup" type="button" className="btn" onClick={onChange}  >
                        Sign Up
                    </Link>
        </div>
        </div>
        
    );
};

export default Login
