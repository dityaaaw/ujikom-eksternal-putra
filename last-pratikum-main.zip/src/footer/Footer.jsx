import React from 'react';

function NewsFooter() {
  return (
    <footer style={styles.footer}>
      <div style={styles.inner}>
        <div style={styles.column}>
          <h4>Tentang Kami</h4>
          <p>Seputar Indonesia Adalah Portal Berita Teraktual, Tajam, Dan Terpercaya</p>
        </div>
        <div style={styles.column}>
          <h4>Kontak</h4>
          <p>Email: Seputar Indonesia@gmail.com</p>
          <p>Telepon: 62 34561 387163</p>
        </div>
        <div style={styles.column}>
          <h4>Ikuti Kami</h4>
          <p>Temukan kami di media sosial:</p>
          <div style={styles.socialIcons}>
            <a href="https://facebook.com"><i className="fab fa-facebook"></i></a>
            <a href="https://twitter.com"><i className="fab fa-twitter"></i></a>
            <a href="https://instagram.com"><i className="fab fa-instagram"></i></a>
          </div>
        </div>
      </div>
    </footer>
  );
}

const styles = {
  footer: {
    backgroundColor: '#222',
    color: '#fff',
    padding: '40px 0',
  },
  inner: {
    maxWidth: '1200px',
    margin: '0 auto',
    display: 'flex',
    justifyContent: 'space-between',
    alignItems: 'flex-start',
  },
  column: {
    flex: 1,
    marginRight: '20px',
  },
  socialIcons: {
    marginTop: '10px',
    fontSize: '24px',
  },
};

export default NewsFooter